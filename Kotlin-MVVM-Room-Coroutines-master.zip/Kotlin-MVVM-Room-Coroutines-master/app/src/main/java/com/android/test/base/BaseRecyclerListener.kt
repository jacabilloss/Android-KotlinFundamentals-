package com.android.test.base
interface BaseRecyclerListener {
}